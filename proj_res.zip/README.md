# Restaurant Landing Page

- Used bootstrap tools & own styles.
- Implemented responsive template.

👉🏻 [Demo](hhttps://bibekb12.github.io/srbjp/)

![Demo](img/demo.gif)